-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.203.217.53    Database: noah
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `exchange_rate` double DEFAULT NULL,
  `is_deleted` bit(1) NOT NULL,
  `type` int NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `receiver_id` bigint DEFAULT NULL,
  `travel_id` bigint DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `travel_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `FK1jpw68rbaxvu8u5l1dniain1l` (`receiver_id`),
  CONSTRAINT `FK1jpw68rbaxvu8u5l1dniain1l` FOREIGN KEY (`receiver_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (NULL,_binary '',1,'2024-04-02 11:09:57.391837','2024-04-02 11:09:57.391837',1,1,2,NULL,'진구진구의여행'),(NULL,_binary '\0',1,'2024-04-02 11:13:28.164174','2024-04-02 11:13:28.164174',2,4,2,NULL,'진구진구의여행'),(NULL,_binary '\0',1,'2024-04-02 11:14:46.496668','2024-04-02 11:14:46.496668',3,2,3,NULL,'남극여행'),(NULL,_binary '',1,'2024-04-02 15:26:33.227786','2024-04-02 15:26:33.227786',4,7,8,NULL,'5월 벚꽃 일본 여행'),(NULL,_binary '',2,'2024-04-02 18:00:00.048113','2024-04-02 18:00:00.048113',5,1,1,NULL,'진구의새로운여행'),(NULL,_binary '\0',1,'2024-04-03 01:50:20.893293','2024-04-03 01:50:20.893293',6,7,11,NULL,'남극여행'),(NULL,_binary '\0',1,'2024-04-03 01:50:40.860900','2024-04-03 01:50:40.860900',7,9,11,NULL,'남극여행'),(NULL,_binary '',1,'2024-04-03 02:56:37.827660','2024-04-03 02:56:37.827660',8,1,11,NULL,'남극여행'),(NULL,_binary '\0',2,'2024-04-03 00:00:00.000000','2024-04-03 00:00:00.000000',10,7,8,NULL,'5월 벚꽃 일본 여행'),(NULL,_binary '\0',1,'2024-04-03 10:20:11.167003','2024-04-03 10:20:11.167003',12,7,15,NULL,'New York~'),(183.77,_binary '\0',3,'2024-04-03 20:10:00.000000','2024-04-03 11:10:00.000000',13,7,8,'JPY','5월 벚꽃 일본 여행'),(NULL,_binary '',1,'2024-04-03 13:40:16.836617','2024-04-03 13:40:16.836617',14,1,16,NULL,'박지운필리핀일대기'),(NULL,_binary '\0',1,'2024-04-03 13:58:29.172082','2024-04-03 13:58:29.172082',16,10,1,NULL,'진구의새로운여행');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 15:59:52
