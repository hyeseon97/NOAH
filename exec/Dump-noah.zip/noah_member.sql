-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.203.217.53    Database: noah
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `is_deleted` bit(1) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `notification_token` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `userkey` varchar(255) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (_binary '\0','2024-04-02 11:05:51.636714',1,'2024-04-03 15:33:37.684802','dmdkvj369@naver.com','여진구','레어진구','string','$2a$10$Uj4eS7FaE/94HeQJ1KDGAu9C7Pfq8q/WtRoTLhC.ayAfZ1H4cgxQm','8fa89117-2e9e-47d9-8261-21a425dad6a5'),(_binary '\0','2024-04-02 11:08:58.011718',2,'2024-04-02 11:12:46.000703','jingu8497@gmail.com','여진구','진구진구','eBk0EkCg29fi-JIblvp1Yi:APA91bFIWDd34eCH6tBeiAywnW4JoxPAyQ5y7eJUPG9-nwUys-DklYB87VIbMsbK2OV7nfIMuu9NWrxoB69C6CG1flF2EPK47hGK8gDjMgZE1vwr2yLZQIDLzLm4h6i1awMA_ejRtM_2','$2a$10$gw7p7rW72zEtNzv1cp6gy.glPRrxpyYXZ86/LSmg.rIKuvzN4811.','97b2a709-26e2-475f-b758-aabbbeddc8ba'),(_binary '','2024-04-02 11:10:41.548004',3,'2024-04-02 11:10:41.548004','d','이우진','이우진',NULL,'$2a$10$QcHtBdAA1X6bZSpellqmzu3MSmfYnrraUxQFtNjzSfVBIv.C18KOu','671f5dd6-f2d0-4299-ac1c-be4af485d624'),(_binary '\0','2024-04-02 11:12:13.665545',4,'2024-04-03 15:39:48.005368','dldnwls009@gmail.com','이우진','이우진이우진','null','$2a$10$ybrefVDusvCsyfvMGCiAP.xnD2WQgn6ekG9WL1Dp3FACH7B2ICGiO','671f5dd6-f2d0-4299-ac1c-be4af485d624'),(_binary '\0','2024-04-02 11:16:39.906072',5,'2024-04-02 12:09:48.390226','o54711254@gmail.com','오건영','육건영',NULL,'$2a$10$z8BRwW3YGfHSCh81.RV8HO9UOkemcFoGg.b7VHZdXxdvSz3l5iPKa','84eb80a8-0fde-4932-96b7-cf2a97a897e3'),(_binary '\0','2024-04-02 15:12:33.229539',6,'2024-04-03 15:51:03.198622','qkr8364@naver.com','박혜선','헤서언','null','$2a$10$O/xFUFAsH5UY4iF0m3rfKOlpJ3/PfJXwObB/skt0ikceOZtd2YHWa','af9315b0-d33c-4e36-8c73-649fc311d662'),(_binary '\0','2024-04-02 15:24:01.638202',7,'2024-04-03 10:19:15.974119','hyeseoni_i@naver.com','김노아','노아',NULL,'$2a$10$3NcY5rCEgRmsOu6HdK9VPeOCnFZRfRIac74QlPvSk5e8C9o/inieO','5203f799-ccef-4956-867f-4d679b8c3edb'),(_binary '\0','2024-04-02 17:06:15.454955',8,'2024-04-03 15:46:22.334150','wjsguscjf23@naver.com','김로이','로이킴','cxreebtSAA8H5FZpk5VJXk:APA91bGEPgjCItFBMbSOfRRiI8C4oOZUL0lFTTubnomVOt0bimXxC3slT4IJt0GKBZiyNJkbNFGLe8rvUXuU_sbOe02IdZcazJbc7YXoCngOC0kirjAKRpo8Ty4FY8SmAKuZ4sZHrIPH','$2a$10$IxOYk.tm8orfRaMyeVWReeCngfxS.oXj.DB3fA2ySPIdmxEyI4QWK','556b141d-6578-4975-8385-1c06a99eaff6'),(_binary '\0','2024-04-03 01:14:03.615289',9,'2024-04-03 01:14:03.615289','hyeseon_97@naver.com','박혜선','혜선',NULL,'$2a$10$b1paQLRh30Fj2Ee4dNyiK.T.gY1.loD3wXD4k86uNruN3X65fNTES','d78a2e47-8990-42e1-a58b-e8e054d3d7ed'),(_binary '\0','2024-04-03 13:25:10.069466',10,'2024-04-03 13:25:10.069466','dmdkvj369@hanyang.ac.kr','박지운','핫식스더킹',NULL,'$2a$10$H8ZNEIB1iEGGtxxBgNJDwOdxbKH7Dtb3i2k5pa3wN0j/XHdIwViKW','7c4c8e2f-4ed4-4e61-ab80-6916fa8f8bfb');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 15:59:50
