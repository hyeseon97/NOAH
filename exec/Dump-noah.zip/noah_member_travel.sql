-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.203.217.53    Database: noah
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_travel`
--

DROP TABLE IF EXISTS `member_travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_travel` (
  `auto_transfer` bit(1) DEFAULT NULL,
  `is_deleted` bit(1) NOT NULL,
  `payment_amount` int NOT NULL,
  `account_id` bigint DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `member_travel_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_at` datetime(6) DEFAULT NULL,
  `travel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`member_travel_id`),
  KEY `FK883f5eyhdty4gespqbooynt9p` (`account_id`),
  KEY `FKoh7o2w3i93ww43slti9j65bvw` (`member_id`),
  KEY `FKagpadb7spocsupwucgicw5qfh` (`travel_id`),
  CONSTRAINT `FK883f5eyhdty4gespqbooynt9p` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `FKagpadb7spocsupwucgicw5qfh` FOREIGN KEY (`travel_id`) REFERENCES `travel` (`travel_id`),
  CONSTRAINT `FKoh7o2w3i93ww43slti9j65bvw` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_travel`
--

LOCK TABLES `member_travel` WRITE;
/*!40000 ALTER TABLE `member_travel` DISABLE KEYS */;
INSERT INTO `member_travel` VALUES (_binary '\0',_binary '\0',530000,NULL,'2024-04-02 11:06:18.938860',1,1,'2024-04-02 22:34:06.258908',1),(_binary '\0',_binary '\0',0,NULL,'2024-04-02 11:09:48.957820',2,2,'2024-04-02 11:09:48.957820',2),(_binary '\0',_binary '\0',0,NULL,'2024-04-02 11:14:20.375142',4,3,'2024-04-02 11:14:20.375142',3),(_binary '\0',_binary '\0',350000,NULL,'2024-04-02 12:10:25.223449',5,4,'2024-04-03 15:39:29.321557',4),(_binary '\0',_binary '\0',0,NULL,'2024-04-02 13:08:29.040118',1,5,'2024-04-02 13:08:29.040118',5),(_binary '\0',_binary '\0',10000,NULL,'2024-04-02 13:44:01.338202',1,6,'2024-04-03 01:59:49.539039',6),(_binary '\0',_binary '\0',20000,NULL,'2024-04-02 13:54:12.861091',5,7,'2024-04-03 01:23:39.531396',7),(_binary '\0',_binary '\0',0,NULL,'2024-04-02 15:13:24.073358',6,8,'2024-04-02 15:13:24.073358',8),(_binary '\0',_binary '\0',470000,NULL,'2024-04-02 15:26:42.671901',7,9,'2024-04-03 10:49:27.237268',8),(_binary '\0',_binary '\0',0,NULL,'2024-04-02 17:06:31.467330',8,10,'2024-04-02 17:06:31.467330',9),(_binary '\0',_binary '\0',60000,NULL,'2024-04-03 01:31:37.307379',5,11,'2024-04-03 01:33:37.362852',10),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 01:42:09.915814',6,12,'2024-04-03 01:42:09.915814',11),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 01:50:25.346475',1,13,'2024-04-03 01:50:25.346475',12),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 01:58:42.054552',1,14,'2024-04-03 01:58:42.054552',13),(_binary '\0',_binary '\0',50000,NULL,'2024-04-03 02:56:51.238602',1,15,'2024-04-03 02:57:20.094843',11),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 10:13:59.498353',9,16,'2024-04-03 10:13:59.498353',14),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 10:15:37.385286',9,17,'2024-04-03 10:15:37.385286',15),(_binary '',_binary '\0',250000,NULL,'2024-04-03 13:36:46.591475',10,18,'2024-04-03 13:57:37.242676',16),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 13:48:12.391995',10,19,'2024-04-03 13:48:12.391995',17),(_binary '\0',_binary '\0',630000,NULL,'2024-04-03 13:50:54.825116',1,20,'2024-04-03 13:58:47.498771',16),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 14:55:20.977067',1,21,'2024-04-03 14:55:20.977067',18),(_binary '\0',_binary '\0',0,NULL,'2024-04-03 15:00:22.512257',1,22,'2024-04-03 15:00:22.512257',19);
/*!40000 ALTER TABLE `member_travel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 15:59:54
