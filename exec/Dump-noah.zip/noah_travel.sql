-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.203.217.53    Database: noah
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `travel`
--

DROP TABLE IF EXISTS `travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel` (
  `is_deleted` bit(1) NOT NULL,
  `is_ended` bit(1) NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `travel_id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`travel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel`
--

LOCK TABLES `travel` WRITE;
/*!40000 ALTER TABLE `travel` DISABLE KEYS */;
INSERT INTO `travel` VALUES (_binary '\0',_binary '\0','2024-04-02 11:06:18.918777','2024-04-02 11:06:18.918777',1,'진구의새로운여행'),(_binary '\0',_binary '\0','2024-04-02 11:09:48.952701','2024-04-02 11:09:48.952701',2,'진구진구의여행'),(_binary '\0',_binary '\0','2024-04-02 11:14:20.371065','2024-04-02 11:14:20.371065',3,'남극여행'),(_binary '\0',_binary '\0','2024-04-02 12:10:25.094767','2024-04-02 12:10:25.094767',4,'진짜 멋있는 여행'),(_binary '\0',_binary '\0','2024-04-02 13:08:28.979601','2024-04-02 13:08:28.979601',5,'여행 만들어요'),(_binary '\0',_binary '\0','2024-04-02 13:44:01.317534','2024-04-02 13:44:01.317534',6,'혜선아 이거 되니'),(_binary '\0',_binary '\0','2024-04-02 13:54:12.725223','2024-04-02 13:54:12.725223',7,'짱 멋있는 여행'),(_binary '\0',_binary '\0','2024-04-02 15:13:24.053162','2024-04-02 15:13:24.053162',8,'5월 벚꽃 일본 여행'),(_binary '\0',_binary '\0','2024-04-02 17:06:31.432713','2024-04-02 17:06:31.432713',9,'범진씨의인사'),(_binary '\0',_binary '\0','2024-04-03 01:31:37.275122','2024-04-03 01:31:37.275122',10,'정말멋있는여행'),(_binary '\0',_binary '\0','2024-04-03 01:42:09.883818','2024-04-03 01:42:09.883818',11,'남극여행'),(_binary '\0',_binary '\0','2024-04-03 01:50:25.336500','2024-04-03 01:50:25.336500',12,'남극여행'),(_binary '\0',_binary '\0','2024-04-03 01:58:42.050820','2024-04-03 01:58:42.050820',13,'다시ㅣ테스트'),(_binary '\0',_binary '\0','2024-04-03 10:13:59.491440','2024-04-03 10:13:59.491440',14,'캥거루 보러 호주 가자'),(_binary '\0',_binary '\0','2024-04-03 10:15:37.382160','2024-04-03 10:15:37.382160',15,'New York~'),(_binary '\0',_binary '\0','2024-04-03 13:36:46.558984','2024-04-03 13:36:46.558984',16,'박지운필리핀일대기'),(_binary '\0',_binary '\0','2024-04-03 13:48:12.371932','2024-04-03 13:48:12.371932',17,'박지운명적인여행'),(_binary '\0',_binary '\0','2024-04-03 14:55:20.957485','2024-04-03 14:55:20.957485',18,'테스트'),(_binary '\0',_binary '\0','2024-04-03 15:00:22.492166','2024-04-03 15:00:22.492166',19,'새로운계획을만들자');
/*!40000 ALTER TABLE `travel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 15:59:51
