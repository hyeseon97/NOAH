-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.203.217.53    Database: noah
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_account`
--

DROP TABLE IF EXISTS `group_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_account` (
  `is_deleted` bit(1) NOT NULL,
  `payment_date` int DEFAULT NULL,
  `per_amount` int DEFAULT NULL,
  `target_amount` int DEFAULT NULL,
  `target_date` int DEFAULT NULL,
  `used_amount` int DEFAULT NULL,
  `account_id` bigint DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `group_account_id` bigint NOT NULL AUTO_INCREMENT,
  `modified_at` datetime(6) DEFAULT NULL,
  `travel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`group_account_id`),
  UNIQUE KEY `UK_bavim2ssereqxbv94niphboji` (`account_id`),
  UNIQUE KEY `UK_gywcdaco2aei9y3m6g4l8r3jf` (`travel_id`),
  CONSTRAINT `FKfog6gclq6p5hibay41yualj1l` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`),
  CONSTRAINT `FKm2f7evudxfkx0cygaf39h1w07` FOREIGN KEY (`travel_id`) REFERENCES `travel` (`travel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_account`
--

LOCK TABLES `group_account` WRITE;
/*!40000 ALTER TABLE `group_account` DISABLE KEYS */;
INSERT INTO `group_account` VALUES (_binary '\0',2,30000,2000000,20240409,0,4,'2024-04-02 11:06:19.169474',1,'2024-04-03 01:31:17.480423',1),(_binary '\0',0,0,0,0,0,9,'2024-04-02 11:09:49.195979',2,'2024-04-02 11:09:49.195979',2),(_binary '\0',0,0,0,0,0,15,'2024-04-02 11:14:20.559990',3,'2024-04-02 11:14:20.559990',3),(_binary '\0',1,35000,1600000,20241020,0,20,'2024-04-02 12:10:27.034465',4,'2024-04-02 15:28:00.620620',4),(_binary '\0',0,0,0,0,0,21,'2024-04-02 13:08:29.480107',5,'2024-04-02 13:08:29.480107',5),(_binary '\0',0,0,10000,0,0,22,'2024-04-02 13:44:01.755494',6,'2024-04-03 01:59:34.691913',6),(_binary '\0',0,0,0,0,0,23,'2024-04-02 13:54:14.602188',7,'2024-04-02 13:54:14.602188',7),(_binary '\0',1,300000,1300000,20240521,0,25,'2024-04-02 15:13:24.280561',8,'2024-04-03 01:15:23.304644',8),(_binary '\0',0,0,0,0,0,34,'2024-04-02 17:06:31.859728',9,'2024-04-02 17:06:31.859728',9),(_binary '\0',0,0,0,0,0,37,'2024-04-03 01:31:37.791603',10,'2024-04-03 01:31:37.791603',10),(_binary '\0',0,0,0,0,0,38,'2024-04-03 01:42:10.144685',11,'2024-04-03 01:42:10.144685',11),(_binary '\0',0,0,0,0,0,39,'2024-04-03 01:50:25.533119',12,'2024-04-03 01:50:25.533119',12),(_binary '\0',0,0,0,0,0,40,'2024-04-03 01:58:42.205524',13,'2024-04-03 01:58:42.205524',13),(_binary '\0',0,0,0,0,0,41,'2024-04-03 10:13:59.658317',14,'2024-04-03 10:13:59.658317',14),(_binary '\0',0,0,0,0,0,42,'2024-04-03 10:15:37.530184',15,'2024-04-03 10:15:37.530184',15),(_binary '\0',2,50000,1000000,20241203,0,46,'2024-04-03 13:36:47.100126',16,'2024-04-03 13:57:19.319755',16),(_binary '\0',0,0,0,0,0,47,'2024-04-03 13:48:12.864811',17,'2024-04-03 13:48:12.864811',17),(_binary '\0',0,0,0,0,0,48,'2024-04-03 14:55:21.351313',18,'2024-04-03 14:55:21.351313',18),(_binary '\0',0,0,0,0,0,49,'2024-04-03 15:00:22.931038',19,'2024-04-03 15:00:22.931038',19);
/*!40000 ALTER TABLE `group_account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 15:59:54
